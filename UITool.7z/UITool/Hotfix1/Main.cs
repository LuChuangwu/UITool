﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UITool;
using UITool.Logic;

namespace Hotfix1
{
    public  class Main
    {
       public static void  HotFix(string[] args)
        {
            HotFixBLL.print = new HotPrint();
        }
        public class HotPrint : PrintBase
        {
            public override void Say()
            {
                Console.WriteLine("重写");
            }
        }

    }
}
