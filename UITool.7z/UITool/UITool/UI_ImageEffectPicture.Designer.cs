﻿namespace UITool
{
    partial class UI_ImageEffectPicture
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UI_ImageEffectPicture));
            this.img_picture = new System.Windows.Forms.PictureBox();
            this.btn_delet = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.img_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_delet)).BeginInit();
            this.SuspendLayout();
            // 
            // img_picture
            // 
            this.img_picture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.img_picture.Location = new System.Drawing.Point(0, 0);
            this.img_picture.Name = "img_picture";
            this.img_picture.Size = new System.Drawing.Size(230, 150);
            this.img_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.img_picture.TabIndex = 0;
            this.img_picture.TabStop = false;
            // 
            // btn_delet
            // 
            this.btn_delet.Image = ((System.Drawing.Image)(resources.GetObject("btn_delet.Image")));
            this.btn_delet.Location = new System.Drawing.Point(195, 3);
            this.btn_delet.Name = "btn_delet";
            this.btn_delet.Size = new System.Drawing.Size(32, 32);
            this.btn_delet.TabIndex = 1;
            this.btn_delet.TabStop = false;
            this.btn_delet.Click += new System.EventHandler(this.Btn_delet_Click);
            // 
            // UI_ImageEffectPicture
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btn_delet);
            this.Controls.Add(this.img_picture);
            this.Name = "UI_ImageEffectPicture";
            this.Size = new System.Drawing.Size(230, 150);
            ((System.ComponentModel.ISupportInitialize)(this.img_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_delet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox img_picture;
        private PictureBox btn_delet;
    }
}
