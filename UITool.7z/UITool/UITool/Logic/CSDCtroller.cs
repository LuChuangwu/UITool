﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using UITool.Data;

namespace UITool.Logic
{
    public class CSDCtroller : XmlControllerBase
    {
        XmlDocument document = new XmlDocument();
        public XmlElement node_root;
        string root_path;
        public CSDCtroller(string path)
        {
            document.Load(path);
            string version = "version_"+((XmlElement)document.ChildNodes[0].ChildNodes[0]).GetAttribute("Version").Replace('.', '_');
            node_root = document.SelectSingleNode(CSDVersionContent._Instance[version]) as XmlElement;

        }
        public override void GetAllChilNode(XmlNodeList nodeList, Action<XmlNode> callBack)
        {
           
                foreach (XmlElement element in nodeList)
                {
                    callBack(element);
                    if (element.SelectSingleNode("Children") != null)
                    {
                        GetAllChilNode(element.SelectSingleNode("Children").ChildNodes, callBack);
                    }

                }

           
          
            //throw new NotImplementedException();
        }

        public override string GetNodePath(XmlElement element)
        {
            throw new NotImplementedException();
        }
        public List<string> GetAllNodeResources(string folder)
        {
            Console.WriteLine(folder);
            List<string> resources_item = new List<string>();
            GetAllChilNode(node_root.ChildNodes, (node) =>
            {
               
                foreach (XmlElement item in node.ChildNodes)
                {
                    if (!string.IsNullOrEmpty(item.GetAttribute("Path")))
                    {
                        if (File.Exists(folder + "\\" + item.GetAttribute("Path").Replace("/", "\\")))
                        {
                            resources_item.Add(folder + "\\" + item.GetAttribute("Path").Replace("/", "\\"));

                        }
                     
                       // Console.WriteLine(item.GetAttribute("Path"));
                       
                    }
                    if (!string.IsNullOrEmpty(item.GetAttribute("Plist")))
                    {
                        if (File.Exists(folder + "\\" + item.GetAttribute("Plist").Replace("/", "\\")))
                        {
                            resources_item.Add(folder + "\\" + item.GetAttribute("Plist").Replace("/", "\\"));

                        }
                    }
                }
            });
            return resources_item;

        }
    }
}
