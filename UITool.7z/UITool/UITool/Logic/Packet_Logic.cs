﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UITool.Utils;

namespace UITool.Logic
{
    public  class Packet_Logic:Instance<Packet_Logic>
    {
        private List<string> csd_path = new List<string>();
        private List<string> removehistory = new List<string>();
        private List<string> img_effectpicture = new List<string>();
        private Dictionary<string, List<string>> res_user = new Dictionary<string, List<string>>();
        string folder;

        public List<string> Removehistory { get => removehistory;  }

        public bool CanAdd(string folder,string path)
        {
            if (csd_path.Contains(path))
            {
                Console.WriteLine(path);
                return false;
            }
            this.folder = folder;
            if (AnalyzeCsd(path, folder).Count>0)
            {
                GetResources(AnalyzeCsd(path, folder), path);

            }
            Console.WriteLine(csd_path.Count);


            return true;
        }
        public void ReMoveCsd(string path)
        {
            if (csd_path.Contains(path))
            {
                csd_path.Remove(path);
                foreach (var item in res_user)
                {
                    if (item.Value.Contains(path))
                    {

                        item.Value.Remove(path);
                        if (item.Value.Count <= 0)
                        {
                            Removehistory.Add(item.Key);
                            res_user.Remove(item.Key);
                        }

                    }
                }


            }






        }

        public void ReMoveCsd()
        {
            csd_path.Clear();

        }
        public void GetResources(List<string> res_items,string parent)
        {
            
            foreach (var item in res_items)
            {
              
                AddResourcesItem(item, parent);
                string flitter = item.Substring(item.LastIndexOf('.') + 1);
               
                switch (flitter)
                {

                    case "csd":
                       if(AnalyzeCsd(item, folder).Count>0)
                        {
                            GetResources(AnalyzeCsd(item, folder), parent);

                        }
                      //  csd_path.Add(item);
                        break;
                    case "fnt":
                        string []content = FileController._Instance.GetStringLineFromFile(item);
                        string file_name = (content[2].Substring(content[2].IndexOf('"') + 1));
                        AddResourcesItem(item.Substring(0, item.LastIndexOf("\\") + 1) + file_name.Substring(0, file_name.Length - 1), parent);
                        break;
                    case "csi":
                        CSICtroller csi = new CSICtroller(item);
                        GetResources(csi.GetAllResources(), parent);
                        break;
                    case "plist":
                        PlistController plist = new PlistController(item);
                        AddResourcesItem(plist.GetALLResources(item.Substring(0, item.LastIndexOf("\\") + 1)),parent);
                        break;
                    default:
                        break;
                }



            }

        }

        public void AddResourcesItem(string res_path,string csd_project_path)
        {
            Console.WriteLine(res_path);
           
            if (!res_user.ContainsKey(res_path))
            {
              
                List<string> _used_csd = new List<string>();
                _used_csd.Add(csd_project_path);
                res_user.Add(res_path, _used_csd);
            }
            else
            {
                if (!res_user[res_path].Contains(csd_project_path))
                {
                  
                    res_user[res_path].Add(csd_project_path);
                }
            }
           
        }
        public void AddResourcesItem(List<string> res_path_list, string csd_project_path)
        {
            foreach (string res_path in res_path_list)
            {

                if (!res_user.ContainsKey(res_path))
                {

                    List<string> _used_csd = new List<string>();
                    _used_csd.Add(csd_project_path);
                    res_user.Add(res_path, _used_csd);
                }
                else
                {
                    if (!res_user[res_path].Contains(csd_project_path))
                    {

                        res_user[res_path].Add(csd_project_path);
                    }
                }

            }

        }
        public IEnumerable<string> GetAllResources()
        {
           
            if (res_user.Count>0)
            {
                return res_user.Keys;
            }
            return null;
        }

        public List<string> AnalyzeCsd(string path,string folder)
        {
            
            CSDCtroller csdcontroller = new CSDCtroller(path);
            List<string> res_item = new List<string>();
            res_item = csdcontroller.GetAllNodeResources(folder);

            if (!csd_path.Contains(path))
            {
                csd_path.Add(path);


            }
            return res_item;


        }

        public void AddImagePicture(string path)
        {
            if (!img_effectpicture.Contains(path))
            {
                img_effectpicture.Add(path);
            }
        }
        public void ReMovePicture(string path)
        {
            if (!img_effectpicture.Contains(path))
            {
                img_effectpicture.Remove(path);
            }
        }
        public bool CanAddPicture(string path)
        {
            if (img_effectpicture.Contains(path))
            {

                return false;

            }
            return true;
        }


        public void Packet()
        {
            csd_path.Clear();
            res_user.Clear();
            img_effectpicture.Clear();
        }

        internal void PacketResources(string newfolder)
        {
            Thread copy = new Thread(() => 
            {
                string target_folder = newfolder + "\\Packet\\CocosStudioProject\\cocosstudio\\";
                string effectpicture = newfolder + "\\Packet\\效果图\\";
                if (!Directory.Exists(target_folder))
                {
                    Directory.CreateDirectory(target_folder);
                }
                if (!Directory.Exists(effectpicture))
                {
                    Directory.CreateDirectory(effectpicture);
                }
                //复制csd
                foreach (string csd_file  in csd_path)
                {
                    if (File.Exists(csd_file))
                    {
                        string createfolder = csd_file.Substring(folder.Length+1);
                        if (!createfolder.Contains("\\"))
                        {
                            FileController._Instance.CopyFile(csd_file, target_folder + createfolder);
                        }
                        else
                        {
                            string needfolder = createfolder.Substring(0, createfolder.LastIndexOf("\\"));
                            string needfile=createfolder.Substring(createfolder.LastIndexOf("\\")+1);
                            FileController._Instance.CreateFolder(newfolder , "\\Packet\\CocosStudioProject\\cocosstudio\\" + needfolder);
                            FileController._Instance.CopyFile(csd_file, target_folder + needfolder+ "\\" + needfile);
                        }
                        
                    }

                }
                //复制资源
                foreach (var item in res_user)
                {
                    if (File.Exists(item.Key))
                    {
                        string createfolder = item.Key.Substring(folder.Length + 1);
                        if (!createfolder.Contains("\\"))
                        {
                            FileController._Instance.CopyFile(item.Key, newfolder + "\\" + createfolder);
                        }
                        else
                        {
                            string needfolder = createfolder.Substring(0, createfolder.LastIndexOf("\\"));
                            string needfile = createfolder.Substring(createfolder.LastIndexOf("\\") + 1);
                            FileController._Instance.CreateFolder(newfolder, "\\Packet\\CocosStudioProject\\cocosstudio\\" + needfolder);
                            FileController._Instance.CopyFile(item.Key, newfolder + "\\Packet\\CocosStudioProject\\cocosstudio\\" + needfolder + "\\" + needfile);
                        }
                        
                    }
                }
                //复制效果图
                foreach (string  picture_path in img_effectpicture)
                {
                    if (File.Exists(picture_path))
                    {
                        string file_name = picture_path.Substring(picture_path.LastIndexOf("\\")+1);
                        File.Copy(picture_path, effectpicture+ file_name, true);

                    }
                }

                File.Create(newfolder + "\\Packet\\CocosStudioProject\\test.ccs").Dispose();
                CCSController ccs = new CCSController(newfolder + "\\Packet\\CocosStudioProject\\test.ccs");


                Packet();
                

            });
            copy.IsBackground = true;
            copy.Start();


            Console.WriteLine(folder);
        }
    }
}
