﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace UITool.Logic
{

    public class CCSController
    {
        private XmlDocument document=new XmlDocument();
        XmlElement propertygroup;
        XmlElement solutionfolder;
        XmlElement root_folder;
        XmlElement group;
        XmlElement root;
        public CCSController(string path)
        {
            document.LoadXml("Data//template.ccs");
           
            string name = path.Substring(path.LastIndexOf("\\"));
            
            CreateHead(name,"3.10.0.0");
            document.Save(path);
        }

        public void CreateHead(string name,string version)
        {
            ((XmlElement)document.SelectSingleNode("Solution/PropertyGroup")).SetAttribute("Name", name);
            ((XmlElement)document.SelectSingleNode("Solution/PropertyGroup")).SetAttribute("Version", version);
           
        }
    }

}
