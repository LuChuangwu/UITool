﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UITool.Data;
using UITool.Utils;

namespace UITool.Logic
{
    public  class FileController:Instance<FileController>
    {
        /// <summary>
        /// 获取所有csd文件
        /// </summary>
        /// <param name="path"> 文件夹路径</param>
        /// <returns></returns>
        public List<string> GetAllFileNames(string path)
        {
            //if (DataController._Instance.folder_psth.Contains(path))
            //{
            //    MessageBox.Show("已存在该路径工程面板");
            //    return null;
            //}
            if (string.IsNullOrEmpty(path))
            {
                MessageBox.Show("非法路径");
                return null;

            }
            List<string> csd_list = new List<string>();
            csd_list = Util._Instance.GetAllFiles(path, csd_list, "*.csd");
            if (csd_list.Count <= 0)
            {
                MessageBox.Show("该路径下暂未查找到csd文件");
                return null;
            }
            return csd_list;
        }
        public string BrowFolder()
        {
            FolderBrowserDialog folderBrowser = new FolderBrowserDialog();
            DialogResult result = folderBrowser.ShowDialog();
            if (result == DialogResult.OK)
            {
                return folderBrowser.SelectedPath;
            }
            return null;
        }
        public void SaveFile(string folder,string file_name ,string content)
        {
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            if (!File.Exists(folder+file_name))
            {
                File.Create(folder + file_name).Dispose(); ;
            }
            File.WriteAllText(folder + file_name, content);

        }
        /// <summary>
        /// 模糊查询文件
        /// </summary>
        /// <param name="value"></param>
        /// <param name="datalist"></param>
        /// <returns></returns>

        public List<string> SearchFileName(string value, List<string> datalist)
        {
            List<string> result = new List<string>();
            foreach (string item in datalist)
            {
                if (item.Contains(value))
                {
                    result.Add(item);
                }
            }
            return result;
        }

        public Bitmap GetImage(string path)
        {
           
            Stream stream = File.OpenRead(path);
            Bitmap bitmap = new Bitmap(Image.FromStream(stream));
            stream.Dispose();
            stream.Close();
            return bitmap;
        }
    
        public string GetStringFromFile(string path)
        {
            string content = File.ReadAllText(path);
            return content;
            
        }
        public string GetStringFromFile(string path,int startindex,int length)
        {
            string content = File.ReadAllText(path);
            return content.Substring(0,length);

        }
        public string[] GetStringLineFromFile(string path)
        {
            string[] content = File.ReadAllLines(path);
            return content;
           

        }
        public void CopyFile(string source, string destination)
        {
            Console.WriteLine(destination);
            if (File.Exists(source)) 
            {
                File.Copy(source, destination, true);
            }
        }
        public void CreateFolder(string older_folder,string new_folder)
        {
            Console.WriteLine(older_folder + "\\" + new_folder);
            if (!Directory.Exists(older_folder+"\\"+new_folder))
            {
                Directory.CreateDirectory(older_folder + "\\" + new_folder);
            }
        }
    

    }
}
