﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace UITool.Logic
{
    public abstract class XmlControllerBase
    {
        public abstract void GetAllChilNode(XmlNodeList nodeList,Action<XmlNode> callBack);

        public abstract string GetNodePath(XmlElement element);

       // public 
    }
}
