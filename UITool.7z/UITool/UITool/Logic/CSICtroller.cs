﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using UITool.Data;

namespace UITool.Logic
{
    public class CSICtroller : XmlControllerBase
    {
        public XmlDocument document = new XmlDocument();
        XmlNodeList node_root;
        string version;
        public CSICtroller(string csi_path)
        {
            document.Load(csi_path);
            version = ((XmlElement)document.SelectSingleNode("")).GetAttribute("Version");
            node_root = ((XmlElement)document.SelectSingleNode(CSIVersionContent._Instance[version])).ChildNodes;
        }

        public override void GetAllChilNode(XmlNodeList nodeList, Action<XmlNode> callBack)
        {
            foreach (XmlElement item in nodeList)
            {
                callBack(item);
                if (item.ChildNodes.Count>0)
                {
                    GetAllChilNode(item.ChildNodes, callBack);
                }
            }
        }
        public List<string> GetAllResources()
        {
            List<string> allImage = new List<string>();
            GetAllChilNode(node_root, (xmlelement) => 
            {
                if (!string.IsNullOrEmpty(((XmlElement)xmlelement).GetAttribute("Path")))
                {
                    allImage.Add(((XmlElement)xmlelement).GetAttribute("Path"));
                }
            });
            return allImage;
        }
        public override string GetNodePath(XmlElement element)
        {
            throw new NotImplementedException();
        }
    }
}
