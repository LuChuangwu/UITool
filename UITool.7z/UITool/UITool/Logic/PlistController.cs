﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using UITool.Data;

namespace UITool.Logic
{
    internal class PlistController : XmlControllerBase
    {
        public XmlDocument document = new XmlDocument();
        public XmlNodeList root_elemt;

        public PlistController(string path)
        {
            document.Load(path);
            Console.WriteLine(document.SelectSingleNode("plist").Name);
            root_elemt = document.SelectSingleNode("plist").ChildNodes;
        }
        
        public override void GetAllChilNode(XmlNodeList nodeList, Action<XmlNode> callBack)
        {
            foreach (XmlNode node in nodeList)
            {
                
                callBack(node);
                if (node.ChildNodes.Count>0)
                {
                    GetAllChilNode(node.ChildNodes, callBack);

                }
            }
        }

        public override string GetNodePath(XmlElement element)
        {
            throw new NotImplementedException();
        }
        public List<string> GetALLResources(string folder)
        {
            List<string> resources_lits= new List<string>();
            GetAllChilNode(root_elemt, (node) =>
            {
               
                if (((XmlNode)node).InnerText.ToLower().Contains(".png")|| ((XmlNode)node).InnerText.ToLower().Contains(".jpg"))
                {
                    if (File.Exists(folder+ node.InnerText))
                    {
                        resources_lits.Add(folder  + node.InnerText);
                    }
                }
            });
            return resources_lits;

        }
    }
}
