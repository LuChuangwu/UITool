﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UITool.Data;
using UITool.Logic;
using UITool.Utils;

namespace UITool
{
    public partial class UI_BrowCSDPath : UserControl
    {
        public UI_BrowCSDPath()
        {

            InitializeComponent();
            //this.panel_mask.Visible = false;
          //  this.BackColor = Color.Transparent;
        }

        private void Cancle(object sender, EventArgs e)
        {
            Close();
        }

        private void Confirm(object sender, EventArgs e)
        {
            ///to do
            GetAllCSDFile(this.inptu_filepath.Text);
            Close();
        }
        private void Close()
        {
            this.inptu_filepath.Text = "";
            this.Visible = false;
        }
        private void GetAllCSDFile(string path)
        {
            if (FileController._Instance.GetAllFileNames(path)!=null)
            {

                Util._Instance.AddEvent(this.Parent.Parent, "ProjectWindowShowDilo", new object[] { path, FileController._Instance.GetAllFileNames(path) });
               
            }
         
        }

        private void BrowFolderPath(object sender, EventArgs e)
        {
            string folder_path = FileController._Instance.BrowFolder();
            if (!string.IsNullOrEmpty(folder_path))
            {
                this.inptu_filepath.Text = folder_path;
            }
            
        }
    }
}
