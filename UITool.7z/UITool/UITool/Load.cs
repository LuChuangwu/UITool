﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UITool.Data;
using UITool.Logic;

namespace UITool.Utils
{
    public partial class Load : Form
    {
        public Load()
        {
            InitializeComponent();
        }

        private void Init(object sender, EventArgs e)
        {
            Thread thread = new Thread(() => 
            {
                if (File.Exists(FilePath._Instance.csd_project_window_path_folder + FilePath._Instance.csd_project_window_path_file))
                {
                    DataController._Instance.controls.Add(new Packet());
                    List<UI_ProjectWindow> projectWindows = new List<UI_ProjectWindow>();

                    DataController._Instance.folder_path = Util._Instance.JsonToObject<Dictionary<string, List<string>>>(FilePath._Instance.csd_project_window_path_folder + FilePath._Instance.csd_project_window_path_file);
                    int index = 0;
                    foreach (var item in DataController._Instance.folder_path)
                    {
                        if (!Directory.Exists(item.Key))
                        {
                            continue;
                        }
                        index++;
                        Console.WriteLine(index);
                        if (this.InvokeRequired)
                        {
                            this.Invoke(new Action(() =>
                            {

                                UI_ProjectWindow projectWindow = new UI_ProjectWindow(item.Value);
                                projectWindow.Name = item.Key;
                                projectWindows.Add(projectWindow);
                            }));


                        }



                    }
                    this.Invoke(new Action(() =>
                    {


                        Form1 form1 = new Form1(projectWindows);
                        form1.Show();
                        this.Hide();
                        form1.FormClosed += (obj, e) => { this.Close(); };
                    }));
                }
                else
                {
                    Form1 form1 = new Form1();
                    form1.Show();
                    this.Hide();
                    form1.FormClosed += (obj, e) => { this.Close(); };

                }
               
           

                

            });
            thread.IsBackground = true;
            thread.Start();

           
            // Console.WriteLine(DataController._Instance.folder_psth.Count);
                    
        }
    }
}
