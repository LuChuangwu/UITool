﻿namespace UITool
{
    partial class UI_CsdItem
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UI_CsdItem));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lb_csdname = new System.Windows.Forms.Label();
            this.btn_delet = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_delet)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.pictureBox1);
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.btn_delet);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(240, 40);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(36, 36);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lb_csdname);
            this.panel1.Location = new System.Drawing.Point(43, 3);
            this.panel1.Margin = new System.Windows.Forms.Padding(1, 3, 3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(163, 34);
            this.panel1.TabIndex = 1;
            // 
            // lb_csdname
            // 
            this.lb_csdname.AutoSize = true;
            this.lb_csdname.Font = new System.Drawing.Font("Microsoft YaHei UI", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_csdname.Location = new System.Drawing.Point(3, 7);
            this.lb_csdname.MaximumSize = new System.Drawing.Size(160, 0);
            this.lb_csdname.Name = "lb_csdname";
            this.lb_csdname.Size = new System.Drawing.Size(158, 32);
            this.lb_csdname.TabIndex = 0;
            this.lb_csdname.Text = "node_og_activity_cnmars_jiheye_1";
            // 
            // btn_delet
            // 
            this.btn_delet.Image = ((System.Drawing.Image)(resources.GetObject("btn_delet.Image")));
            this.btn_delet.Location = new System.Drawing.Point(212, 8);
            this.btn_delet.Margin = new System.Windows.Forms.Padding(3, 8, 3, 3);
            this.btn_delet.Name = "btn_delet";
            this.btn_delet.Size = new System.Drawing.Size(25, 24);
            this.btn_delet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_delet.TabIndex = 2;
            this.btn_delet.TabStop = false;
            this.btn_delet.Click += new System.EventHandler(this.RemoveItem);
            // 
            // UI_CsdItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "UI_CsdItem";
            this.Size = new System.Drawing.Size(240, 40);
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_delet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label lb_csdname;
        private PictureBox btn_delet;
    }
}
