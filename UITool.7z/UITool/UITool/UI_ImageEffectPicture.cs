﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UITool.Logic;
using UITool.Utils;

namespace UITool
{
    public partial class UI_ImageEffectPicture : UserControl
    {
        public UI_ImageEffectPicture(string path)
        {
            InitializeComponent();
            Init(path);
        }
        public void Init(string path)
        {
            Console.WriteLine(path);
            this.img_picture.Image = FileController._Instance.GetImage(path);
            this.Name = path;
            Packet_Logic._Instance.AddImagePicture(path);
           
        }

        private void Btn_delet_Click(object? sender, EventArgs e)
        {
            Console.WriteLine(this.Name);

            Packet_Logic._Instance.ReMovePicture(this.Name);
            this.Parent.Controls.Remove(this);
            
        }
    }
}
