﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UITool.Utils
{
    public  class Instance<T> where T:new()
    {
        private static T _instance;
        public static T _Instance
        {
            get
            {
                if (_instance==null)
                {
                    _instance = new T();
                }
                return _instance;
            }
        }
    }
}
