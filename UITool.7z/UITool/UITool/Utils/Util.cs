﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
namespace UITool.Utils
{
    public  class Util:Instance<Util>
    {
        /// <summary>
        /// 添加点击事件
        /// </summary>
        /// <param name="button"> 按钮控件</param>
        /// <param name="type">事件类 </param>
        /// <param name="methodName">函数名称</param>
        /// <param name="parmas">条件</param>
        public void AddClickEvent(Control button,object type,string methodName, object[] parmas)
        {
            button.Click +=(_object,_event)=> 
            {
                type.GetType().GetMethod(methodName).Invoke(type, parmas);
            };
        }
        /// <summary>
        /// 添加点击事件
        /// </summary>
        /// <param name="button"> 按钮控件</param>
        /// <param name="type">事件类 </param>
        /// <param name="methodName">函数名称</param>
        public void AddClickEvent(Control button, object type, string methodName)
        {
            button.Click += (_object, _event) =>
            {
                type.GetType().GetMethod(methodName).Invoke(type, null);
            };
        }
        public void AddEvent(object type, string methodName)
        {
          
              type.GetType().GetMethod(methodName).Invoke(type, null);
            
        }
        /// <summary>
        /// 添加事件
        /// </summary>
        /// <param name="type"> 事件类</param>
        /// <param name="methodName"> 函数名称</param>
        /// <param name="parmas"> 条件</param>
        public void AddEvent(object type, string methodName, object[] parmas)
        {

            type.GetType().GetMethod(methodName).Invoke(type, parmas);

        }
       
        public List<string> GetAllFiles(string path,List<string> file_list,string file_flliter)
        {
            string[] fillter = file_flliter.Split("*.");
            FileSystemInfo[] fileSystems = new DirectoryInfo(path).GetFileSystemInfos();
            foreach (var filesystem in fileSystems)
            {
                if (File.Exists(filesystem.FullName) && Array.IndexOf(fillter, filesystem.Name.Split('.')[1])!=-1)
                {
                    file_list.Add(filesystem.FullName);
                }
                else if (Directory.Exists(filesystem.FullName))
                {
                    GetAllFiles(filesystem.FullName, file_list, file_flliter);

                }
               
            }
            return file_list;
        }
        /// <summary>
        /// 将数据转换成Json格式
        /// </summary>
        /// <param name="data_obj"> 转换对象</param>
        /// <returns></returns>
        public string ObjToJson(object data_obj)
        {
            string json_content = JsonConvert.SerializeObject(data_obj, Formatting.Indented);
            return json_content;
        }
        public T JsonToObject<T>(string file_path)
        {
            string content = File.ReadAllText(file_path);
            return JsonConvert.DeserializeObject<T>(content);

        }
     
        public object CreateObjByName(string name)
        {
            Type type = Type.GetType("UITool." + name);
            object ctrl_obj = Activator.CreateInstance(type);
            return ctrl_obj;
        }


    }
}
