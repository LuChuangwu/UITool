
using System.Diagnostics;
using UITool.Data;
using UITool.Logic;
using UITool.Utils;

namespace UITool
{
    public partial class Form1 : Form
    {
        List<UI_ProjectWindow> projectWindows = new List<UI_ProjectWindow>();
        public Form1(List<UI_ProjectWindow> projectWindows)
        {
            InitializeComponent();
            this.projectWindows = projectWindows;
        }
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Init(object sender, EventArgs e)
        {
            UI_EditCocosStudio editCocosStudio = new UI_EditCocosStudio();
            this.panel_root.Controls.Add(editCocosStudio);
            editCocosStudio.AddProjectWindo(projectWindows);
            editCocosStudio.BringToFront();
            DataController._Instance.cocosStudi = editCocosStudio;
           // HotfixMgr.Load("Hotfix1", "Hotfix1.Main", null, "HotFix");
            //Util._Instance.AddClickEvent(this.button1, HotFixBLL.print, "Say");
        }

        private void SaveDataAndClose(object sender, FormClosedEventArgs e)
        {
            FileController._Instance.SaveFile(FilePath._Instance.csd_project_window_path_folder, FilePath._Instance.csd_project_window_path_file, Util._Instance.ObjToJson(DataController._Instance.folder_path));
            
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            Console.WriteLine(this.Height);
        }
    }
}