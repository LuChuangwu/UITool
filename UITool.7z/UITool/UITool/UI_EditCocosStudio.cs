﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UITool.Data;
using UITool.Utils;

namespace UITool
{
    public partial class UI_EditCocosStudio : UserControl
    {
        UI_BrowCSDPath browCSDPath = new UI_BrowCSDPath();
        public UI_EditCocosStudio()
        {
            InitializeComponent();
            
            this.panel_root.Controls.Add(browCSDPath);
            browCSDPath.Location = new Point(((this.Width/2)-(browCSDPath.Width/2)), ((this.Height / 2) - (browCSDPath.Height / 2)));
            browCSDPath.Visible = false;
            this.panel_function.Controls.AddRange(DataController._Instance.controls.ToArray());
            this.panel_function.Controls[0].Visible = true;
            
            
            
        }

        private void AddProjectWindow(object sender, EventArgs e)
        {
            browCSDPath.Visible = true;
            browCSDPath.BringToFront();
           
        }

     

        private void img_mask_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            Image image = Image.FromFile("Image\\img_mask_bg.png");
            graphics.DrawImage(image, new Point(0, 0));
        }
        public void ProjectWindowShowDilo(string path,List<string> csd_file)
        {
            if (this.list_projectwindow.Controls.ContainsKey(path))
            {
                MessageBox.Show(string.Format("已经存在{0}的工程面板", path));
                
                return;
            }
            DataController._Instance.folder_path.Add(path,csd_file);
            UI_ProjectWindow project_window = new UI_ProjectWindow(csd_file);
            project_window.Name = path;
            this.list_projectwindow.Controls.Add(project_window);
         
        }
        public void AddProjectWindo(List<UI_ProjectWindow> projectWindows)
        {
            this.list_projectwindow.Controls.AddRange(projectWindows.ToArray()) ;
        }
        public void EditCocosPriject(string folder,string path)
        {
            // Console.WriteLine("工程路径{0}",path);
            foreach (Control item in this.panel_function.Controls)
            {
                if (item.Visible == true)
                {
                    item.GetType().GetMethod("AddCsdProject").Invoke(item, new object[] { folder,path });
                }
            }
        }
    }
}
