﻿namespace UITool
{
    partial class UI_BrowCSDPath
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_mask = new System.Windows.Forms.Panel();
            this.panel_window = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_cacle = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.inptu_filepath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_mask.SuspendLayout();
            this.panel_window.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_mask
            // 
            this.panel_mask.BackColor = System.Drawing.Color.Transparent;
            this.panel_mask.Controls.Add(this.panel_window);
            this.panel_mask.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_mask.Location = new System.Drawing.Point(0, 0);
            this.panel_mask.Name = "panel_mask";
            this.panel_mask.Size = new System.Drawing.Size(401, 164);
            this.panel_mask.TabIndex = 0;
            // 
            // panel_window
            // 
            this.panel_window.BackColor = System.Drawing.Color.DimGray;
            this.panel_window.Controls.Add(this.groupBox1);
            this.panel_window.Location = new System.Drawing.Point(0, 0);
            this.panel_window.Name = "panel_window";
            this.panel_window.Size = new System.Drawing.Size(400, 162);
            this.panel_window.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.inptu_filepath);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(392, 152);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "设置工程路径";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Controls.Add(this.btn_cacle);
            this.flowLayoutPanel1.Controls.Add(this.button2);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(8, 106);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(378, 40);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 35);
            this.panel1.TabIndex = 0;
            // 
            // btn_cacle
            // 
            this.btn_cacle.Location = new System.Drawing.Point(209, 3);
            this.btn_cacle.Name = "btn_cacle";
            this.btn_cacle.Size = new System.Drawing.Size(80, 35);
            this.btn_cacle.TabIndex = 1;
            this.btn_cacle.Text = "取消";
            this.btn_cacle.UseVisualStyleBackColor = true;
            this.btn_cacle.Click += new System.EventHandler(this.Cancle);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(295, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 35);
            this.button2.TabIndex = 2;
            this.button2.Text = "确认";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Confirm);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button3.Location = new System.Drawing.Point(345, 49);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(41, 28);
            this.button3.TabIndex = 3;
            this.button3.Text = "....\r\n\r\n\r\n";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.BrowFolderPath);
            // 
            // inptu_filepath
            // 
            this.inptu_filepath.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.inptu_filepath.Location = new System.Drawing.Point(8, 49);
            this.inptu_filepath.Name = "inptu_filepath";
            this.inptu_filepath.Size = new System.Drawing.Size(331, 28);
            this.inptu_filepath.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(212, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "输入或选择工程路径：";
            // 
            // UI_BrowCSDPath
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.panel_mask);
            this.Name = "UI_BrowCSDPath";
            this.Size = new System.Drawing.Size(401, 164);
            this.panel_mask.ResumeLayout(false);
            this.panel_window.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel_mask;
        private Panel panel_window;
        private GroupBox groupBox1;
        private Label label1;
        private TextBox inptu_filepath;
        private FlowLayoutPanel flowLayoutPanel1;
        private Panel panel1;
        private Button btn_cacle;
        private Button button2;
        private Button button3;
    }
}
