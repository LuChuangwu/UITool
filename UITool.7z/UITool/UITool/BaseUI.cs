﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UITool
{
    public interface   BaseUI
    {
        public  void AddCsdProject(string folder,string path);
    }
}
