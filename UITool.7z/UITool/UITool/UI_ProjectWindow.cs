﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UITool.Data;
using UITool.Logic;
using UITool.Utils;

namespace UITool
{
    public partial class UI_ProjectWindow : UserControl
    {
       
        List<string> csd_file_fullname_list = new List<string>();
        List<string> csd_file_name_list = new List<string>();
        public UI_ProjectWindow(List<string> data_list)
        {
           
            csd_file_fullname_list = data_list;
            InitializeComponent();
            GetFileName(csd_file_fullname_list);

            
            this.list_csd.Items.AddRange(csd_file_name_list.ToArray());
        }

        private void Close(object sender, EventArgs e)
        {
            DataController._Instance.folder_path.Remove(this.Name);
            this.Parent.Controls.Remove(this);
        }
        private void  GetFileName(List<string> data_list)
        {


            for (int i = 0; i < data_list.Count; i++)
            {
                string file_path = data_list[i];
                string file_name = file_path.Substring(file_path.LastIndexOf("\\") + 1);
                csd_file_name_list.Add(file_name);
               
                
            }
        }

        private void SelectCSDItem(object sender, EventArgs e)
        {
            int index = Array.IndexOf(csd_file_name_list.ToArray(), this.list_csd.SelectedItem);
            DataController._Instance.cocosStudi.GetType().GetMethod("EditCocosPriject").Invoke(DataController._Instance.cocosStudi, new object[] { this.Name,csd_file_fullname_list[index] });
            Packet_Logic._Instance.Removehistory.Clear();
            //Console.WriteLine(csd_file_fullname_list[index]);
        }

        private void Search(object sender, EventArgs e)
        {
            this.list_csd.Items.Clear();
            if (string.IsNullOrEmpty(this.textBox1.Text))
            {
                this.list_csd.Items.AddRange(csd_file_name_list.ToArray());
            }
            else
            {
                this.list_csd.Items.AddRange(FileController._Instance.SearchFileName(this.textBox1.Text, csd_file_name_list).ToArray());
            }
        }
    }
}
