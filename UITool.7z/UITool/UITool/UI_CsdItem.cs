﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UITool.Logic;

namespace UITool
{
    public partial class UI_CsdItem : UserControl
    {
        string path;

        public UI_CsdItem(string path)
        {
            InitializeComponent();
            this.path = path;
            this.lb_csdname.Text = path.Substring(path.LastIndexOf("\\") + 1);
            if (lb_csdname.Height>=30)
            {
                lb_csdname.Location = new Point(3, 0);
            }
        }

        private void RemoveItem(object sender, EventArgs e)
        {
            Packet_Logic._Instance.ReMoveCsd(path);
            ((Packet)this.Parent.Parent.Parent.Parent.Parent).UpdateReaources();
            this.Parent.Controls.Remove(this);
            
        

        }
    }
}
