﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UITool.Logic;
using UITool.Utils;

namespace UITool
{
    public partial class Packet :UserControl, BaseUI
    {
        public Packet()
        {
            InitializeComponent();
            this.Visible = false;
            //this.list_project.ControlRemoved += (obj, e) => 
            //{
            //    UpdateReaources(); 
            //};
        }

        public void AddCsdProject(string folder,string path)
        {
            Thread addcsd = new Thread(() => 
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new Action(() =>
                    {
                        if (Packet_Logic._Instance.CanAdd(folder, path))
                        {
                            UI_CsdItem csdItem = new UI_CsdItem(path);
                            this.list_project.Controls.Add(csdItem);
                            if (Packet_Logic._Instance.GetAllResources() == null)
                            {
                                return;
                            }
                            foreach (var item in Packet_Logic._Instance.GetAllResources())
                            {
                                if (File.Exists(item) && !this.list_resources.Controls.ContainsKey(item))
                                {

                                    UI_ResourcesItem resourcesItem = new UI_ResourcesItem(item);
                                    resourcesItem.Name = item;
                                    this.list_resources.Controls.Add(resourcesItem);

                                }
                            }



                        }


                    }));
                }
            });
            addcsd .IsBackground= true;
            addcsd.Start();

           
           
        }


        /// <summary>
        /// todo
        /// </summary>
        public void  UpdateReaources()
        {
            //List<string> res_delet = new List<string>();
            //res_delet = Packet_Logic._Instance.GetAllResources().ToList<string>();
            //Console.WriteLine(res_delet.Count);
            //  Console.WriteLine(Packet_Logic._Instance.GetDeletResources().Count);

            Thread updat = new Thread(() => 
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new Action(() => 
                    {
                        foreach (string res_path in Packet_Logic._Instance.Removehistory)
                        {

                            if (this.list_resources.Controls.ContainsKey(res_path))
                            {


                                if (res_path.ToLower().EndsWith(".csd"))
                                {
                                    Packet_Logic._Instance.ReMoveCsd(res_path);
                                }
                                this.list_resources.Controls.RemoveByKey(res_path);
                            }
                        }

                    }));
                }
               

            });
            updat.IsBackground = true;
            updat.Start();
             







        }

        private void DropEnterEvent(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void DropPicture(object sender, DragEventArgs e)
        {
            Thread thread = new Thread(() =>
            {
                Array path = ((Array)e.Data.GetData(DataFormats.FileDrop));
                for (int i = 0; i < path.Length; i++)
                {
                    string file_path = path.GetValue(i).ToString();

                    if (File.Exists(file_path) && (file_path.ToLower().EndsWith(".png")|| file_path.ToLower().EndsWith(".jpg")))
                    {
                        if (this.InvokeRequired)
                        {
                            this.Invoke(new Action(() =>
                            {
                                UI_ImageEffectPicture imageEffectPicture = new UI_ImageEffectPicture(file_path);
                                this.list_effectpicture.Controls.Add(imageEffectPicture);
                            }));

                        }
                    }
                    else if (Directory.Exists(file_path))
                    {
                        List<string> effectpicture_list = new List<string>();
                        effectpicture_list = Util._Instance.GetAllFiles(file_path, effectpicture_list, "*.png*.jpg");

                        for (int file_index = 0; file_index < effectpicture_list.Count; file_index++)
                        {
                            if (this.InvokeRequired)
                            {
                                this.Invoke(new Action(() =>
                                {
                                    UI_ImageEffectPicture imageEffectPicture = new UI_ImageEffectPicture(effectpicture_list[file_index]);
                                    this.list_effectpicture.Controls.Add(imageEffectPicture);
                                }));

                            }
                        }
                    }
                }


            });
            thread.IsBackground = true;
            thread.Start();

        }
        private void DropDownEvent(object sender, DragEventArgs e)
        {
            Thread thread = new Thread(() => 
            {
                Array path = ((Array)e.Data.GetData(DataFormats.FileDrop));
                for (int i = 0; i < path.Length; i++)
                {
                    string file_path = path.GetValue(i).ToString();

                    if (File.Exists(file_path) && file_path.ToLower().EndsWith(".csd"))
                    {
                        if (file_path.Contains("cocosstudio"))
                        {
                            AddCsdProject(file_path.Substring(0, file_path.IndexOf("cocosstudio") + 12), file_path);

                        }
                        else
                        {
                            MessageBox.Show("该工程文件不存在引擎加载目录，请查看路径是否正确");
                        }
                    }
                    else if (Directory.Exists(file_path))
                    {
                        List<string> csd_paths = new List<string>();
                        csd_paths = Util._Instance.GetAllFiles(file_path, csd_paths, "*.csd");
                        for (int file_index = 0; file_index < csd_paths.Count; file_index++)
                        {
                            AddCsdProject(file_path, csd_paths[file_index]);
                        }
                    }
                }


            });
            thread.IsBackground= true;
            thread.Start();
        }

        private void AddPicture(object sender, EventArgs e)
        {
           

            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = true;
            DialogResult result =fileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                string[] paths = fileDialog.FileNames;

                Thread add_picture = new Thread(() =>
                {
                    foreach (string path in paths)
                    {
                        if (Packet_Logic._Instance.CanAddPicture(path) && (path.ToLower().EndsWith(".png") || path.ToLower().EndsWith(".jpg")))
                        {
                            if (this.InvokeRequired)
                            {
                                this.Invoke(new Action(() =>
                                {
                                    UI_ImageEffectPicture imageEffectPicture = new UI_ImageEffectPicture(path);
                                    this.list_effectpicture.Controls.Add(imageEffectPicture);
                                }));
                               
                            }
                            else
                            {
                                this.Invoke(new Action(() =>
                                {
                                    UI_ImageEffectPicture imageEffectPicture = new UI_ImageEffectPicture(path);
                                    this.list_effectpicture.Controls.Add(imageEffectPicture);
                                }));
                            }

                        }

                    }
                });
                add_picture.IsBackground  = true;
                add_picture.Start();
             
              
            }
        }

        private void Btn_Packect(object sender, EventArgs e)
        {
            FolderBrowserDialog browserDialog = new FolderBrowserDialog();
            DialogResult dialogResult= browserDialog.ShowDialog();
  
            if (dialogResult==DialogResult.OK)
            {
               
                Packet_Logic._Instance.PacketResources(browserDialog.SelectedPath);
                this.list_project.Controls.Clear();
                this.list_resources.Controls.Clear();
                this.list_effectpicture.Controls.Clear();
            }
        }
    }
}
