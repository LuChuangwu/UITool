﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UITool.Logic;

namespace UITool
{
    public partial class UI_ResourcesItem : UserControl
    {
        private string path;
        public UI_ResourcesItem(string path)
        {
            InitializeComponent();

            this.path = path;
           
            this.label1.Text = path.Substring(path.LastIndexOf("\\") + 1);
            if (this.label1.Height>=32)
            {
                this.label1.Margin = new Padding(3, 0, 3, 0);
            }
            if (path.ToLower().EndsWith(".png")|| path.ToLower().EndsWith(".jpg"))
            {
                this.pictureBox1.Image = FileController._Instance.GetImage(path);
            }
            if (path.ToLower().EndsWith(".fnt"))
            {
                this.pictureBox1.Image = FileController._Instance.GetImage("Image\\img_fonticon_2.png");
            }
            if (path.ToLower().EndsWith(".csd"))
            {
                this.pictureBox1.Image = FileController._Instance.GetImage("Image\\img_csd_icon.png");
            }
            if (path.ToLower().EndsWith(".ttf"))
            {
                this.pictureBox1.Image = FileController._Instance.GetImage("Image\\img_fonticon.png");
            }
            if (path.ToLower().EndsWith(".plist"))
            {
                this.pictureBox1.Image = FileController._Instance.GetImage("Image\\img_plist.png");
            }

        }
        public void ReMove()
        {
            //Console.WriteLine(path);
         
                this.Parent.Controls.Remove(this);
            
        }
    }
}
