﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UITool.Utils;
namespace UITool.Data
{
    internal class DataController:Instance<DataController>
    {
        // public List<string> folder_psth = new List<string>();

        public Dictionary<string, List<string>> folder_path = new Dictionary<string, List<string>>();
        public UI_EditCocosStudio cocosStudi;
        public List<Control> controls = new List<Control>();
       
    }
}
