﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UITool.Utils;

namespace UITool.Data
{
    public  class FilePath:Instance<FilePath>
    {
        public string csd_project_window_path_folder = "Data/";
        public string csd_project_window_path_file = "csd_path.json";
    }
}
