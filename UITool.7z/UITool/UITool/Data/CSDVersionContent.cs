﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UITool.Utils;

namespace UITool.Data
{
    internal class CSDVersionContent:Instance<CSDVersionContent>
    {

       public string version_2_0_6_0 = "GameProjectFile/Content/Content/ObjectData/Children";
       public string version_2_3_3_0 = "GameFile/Content/Content/ObjectData/Children";
       public string version_3_10_0_0 = "GameFile/Content/Content/ObjectData/Children";
       public string version_4_0_0_0 = "GameFile/Content/Content/ObjectData/Children";

        public  string this[string version]
        {
            get
            {
                return this.GetType().GetField(version).GetValue(this).ToString();
                 
            }
        }
    }
    public class CSIVersionContent:Instance<CSIVersionContent>
    {
        public string version_2_0_6_0 = "PlistInfoProjectFile/Content";
        public string version_2_3_3_0 = "PlistInfoProjectFile/Content";
        public string version_3_10_0_0 = "PlistInfoProjectFile/Content";
        public string version_4_0_0_0 = "PlistInfoProjectFile/Content";

        public string this[string version]
        {
            get
            {
                return this.GetType().GetField(version).GetValue(this).ToString();

            }
        }
    }

    public class PlistVersionContent:Instance<PlistVersionContent>
    {
        public string version_1_0 = "plist";
        public string version_2_3_3_0 = "plist";
        public string version_3_10_0_0 = "plist";
        public string version_4_0_0_0 = "plist";

        public string this[string version]
        {
            get
            {
                return this.GetType().GetField(version).GetValue(this).ToString();

            }
        }
    }

    public class CCSType
    {
        public string csd="Project";
        public string png = "Image";
        public string ttf = "TTF";
        public string fnt = "Fnt";
        public string otf = "otf";
        public string plist = "PlistParticleFile";
        public string this[string type]
        {
            get
            {
                return this.GetType().GetField(type).GetValue(this).ToString();

            }
        }
    }

}
