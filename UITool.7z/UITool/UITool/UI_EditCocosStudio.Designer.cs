﻿namespace UITool
{
    partial class UI_EditCocosStudio
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UI_EditCocosStudio));
            this.panel_root = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Packet = new System.Windows.Forms.Button();
            this.Check = new System.Windows.Forms.Button();
            this.Compare = new System.Windows.Forms.Button();
            this.panel_function = new System.Windows.Forms.Panel();
            this.panel_projectarea = new System.Windows.Forms.Panel();
            this.panel_content_1 = new System.Windows.Forms.FlowLayoutPanel();
            this.list_projectwindow = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_addprojectwindow = new UITool.UI.UserButton();
            this.panel_root.SuspendLayout();
            this.panel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel_projectarea.SuspendLayout();
            this.panel_content_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_addprojectwindow)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_root
            // 
            this.panel_root.Controls.Add(this.panel2);
            this.panel_root.Controls.Add(this.panel_function);
            this.panel_root.Controls.Add(this.panel_projectarea);
            this.panel_root.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_root.Location = new System.Drawing.Point(0, 0);
            this.panel_root.Name = "panel_root";
            this.panel_root.Size = new System.Drawing.Size(1194, 794);
            this.panel_root.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.flowLayoutPanel1);
            this.panel2.Location = new System.Drawing.Point(320, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(864, 50);
            this.panel2.TabIndex = 2;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.Packet);
            this.flowLayoutPanel1.Controls.Add(this.Check);
            this.flowLayoutPanel1.Controls.Add(this.Compare);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(860, 46);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // Packet
            // 
            this.Packet.BackColor = System.Drawing.Color.DimGray;
            this.Packet.Location = new System.Drawing.Point(3, 3);
            this.Packet.Name = "Packet";
            this.Packet.Size = new System.Drawing.Size(86, 40);
            this.Packet.TabIndex = 0;
            this.Packet.Text = "打包";
            this.Packet.UseVisualStyleBackColor = false;
            // 
            // Check
            // 
            this.Check.BackColor = System.Drawing.Color.DimGray;
            this.Check.Location = new System.Drawing.Point(95, 3);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(87, 40);
            this.Check.TabIndex = 1;
            this.Check.Text = "检测";
            this.Check.UseVisualStyleBackColor = false;
            // 
            // Compare
            // 
            this.Compare.BackColor = System.Drawing.Color.DimGray;
            this.Compare.Location = new System.Drawing.Point(188, 3);
            this.Compare.Name = "Compare";
            this.Compare.Size = new System.Drawing.Size(89, 40);
            this.Compare.TabIndex = 2;
            this.Compare.Text = "工程对比";
            this.Compare.UseVisualStyleBackColor = false;
            // 
            // panel_function
            // 
            this.panel_function.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel_function.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_function.Location = new System.Drawing.Point(320, 70);
            this.panel_function.Name = "panel_function";
            this.panel_function.Size = new System.Drawing.Size(864, 714);
            this.panel_function.TabIndex = 1;
            // 
            // panel_projectarea
            // 
            this.panel_projectarea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel_projectarea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_projectarea.Controls.Add(this.panel_content_1);
            this.panel_projectarea.Location = new System.Drawing.Point(10, 10);
            this.panel_projectarea.Name = "panel_projectarea";
            this.panel_projectarea.Size = new System.Drawing.Size(300, 774);
            this.panel_projectarea.TabIndex = 0;
            // 
            // panel_content_1
            // 
            this.panel_content_1.BackColor = System.Drawing.Color.Transparent;
            this.panel_content_1.Controls.Add(this.list_projectwindow);
            this.panel_content_1.Controls.Add(this.btn_addprojectwindow);
            this.panel_content_1.Location = new System.Drawing.Point(4, 3);
            this.panel_content_1.Name = "panel_content_1";
            this.panel_content_1.Size = new System.Drawing.Size(289, 764);
            this.panel_content_1.TabIndex = 0;
            // 
            // list_projectwindow
            // 
            this.list_projectwindow.AutoScroll = true;
            this.list_projectwindow.AutoSize = true;
            this.list_projectwindow.Location = new System.Drawing.Point(3, 3);
            this.list_projectwindow.MaximumSize = new System.Drawing.Size(284, 704);
            this.list_projectwindow.MinimumSize = new System.Drawing.Size(284, 0);
            this.list_projectwindow.Name = "list_projectwindow";
            this.list_projectwindow.Size = new System.Drawing.Size(284, 0);
            this.list_projectwindow.TabIndex = 0;
            // 
            // btn_addprojectwindow
            // 
            this.btn_addprojectwindow.Dis_img = ((System.Drawing.Image)(resources.GetObject("btn_addprojectwindow.Dis_img")));
            this.btn_addprojectwindow.Height_img = ((System.Drawing.Image)(resources.GetObject("btn_addprojectwindow.Height_img")));
            this.btn_addprojectwindow.Image = ((System.Drawing.Image)(resources.GetObject("btn_addprojectwindow.Image")));
            this.btn_addprojectwindow.Location = new System.Drawing.Point(3, 9);
            this.btn_addprojectwindow.Name = "btn_addprojectwindow";
            this.btn_addprojectwindow.Normal_img = ((System.Drawing.Image)(resources.GetObject("btn_addprojectwindow.Normal_img")));
            this.btn_addprojectwindow.Size = new System.Drawing.Size(284, 50);
            this.btn_addprojectwindow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.btn_addprojectwindow.TabIndex = 1;
            this.btn_addprojectwindow.TabStop = false;
            this.btn_addprojectwindow.Click += new System.EventHandler(this.AddProjectWindow);
            // 
            // UI_EditCocosStudio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Controls.Add(this.panel_root);
            this.DoubleBuffered = true;
            this.Name = "UI_EditCocosStudio";
            this.Size = new System.Drawing.Size(1194, 794);
            this.panel_root.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel_projectarea.ResumeLayout(false);
            this.panel_content_1.ResumeLayout(false);
            this.panel_content_1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_addprojectwindow)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel_root;
        private Panel panel_projectarea;
        private Panel panel2;
        private Panel panel_function;
        private FlowLayoutPanel panel_content_1;
        private FlowLayoutPanel list_projectwindow;
        private UI.UserButton btn_addprojectwindow;
        private FlowLayoutPanel flowLayoutPanel1;
        private Button Packet;
        private Button Check;
        private Button Compare;
    }
}
