﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UITool.UI
{
    public partial class UserButton : PictureBox
    {

        private Label label = new Label();
        private string tetx = "按钮";
        public UserButton()
        {
            InitializeComponent();
            
            this.Controls.Add(label);
            label.BringToFront();

        }
        private Image normal_img;
        private Image height_img;
        private Image dis_img;
        public int scale_size = 10;
        /// <summary>
        /// 默认图片
        /// </summary>
        
        public Image Normal_img { get => normal_img; set => normal_img = value; }
        /// <summary>
        /// 选择图片
        /// </summary>
        public Image Height_img { get => height_img; set => height_img = value; }
        /// <summary>
        /// 禁用图片
        /// </summary>
        public Image Dis_img { get => dis_img; set => dis_img = value; }


        private void MouseEnterEnwvt(object sender, EventArgs e)
        {
           
            this.Image = Height_img;
        }

        private void MouseLeaveEnwvt(object sender, EventArgs e)
        {
           
            this.Image = Normal_img;
        }

        private void MouseDownEvent(object sender, MouseEventArgs e)
        {
            this.Width -= scale_size;
            this.Height -= scale_size;
        }

        private void MouseUpEvent(object sender, MouseEventArgs e)
        {
            this.Width += scale_size;
            this.Height += scale_size;
        }
    }
}
